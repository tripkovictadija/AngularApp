export interface Zakazivanje {
    id: number;
    ime_pacijenta: string;
    prezime_pacijenta: string;
    naziv: string;
    datum: string;
    vreme: string;
    telefon: string;
}
