export interface DoktorHttp {
    doktori: []
}