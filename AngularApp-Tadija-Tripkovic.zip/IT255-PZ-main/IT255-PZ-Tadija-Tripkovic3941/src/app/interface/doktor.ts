export interface Doktor {
    id?: number;
    ime?: string;
    prezime?: string;
    titula?: string;
    username?: string;
    password?: string;
}

