export interface ZakazivanjeHttp {
    zakazivanja: [];
}
